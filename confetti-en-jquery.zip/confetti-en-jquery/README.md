# Confetti en jQuery

A Pen created on CodePen.

Original URL: [https://codepen.io/GhostRider/pen/ZEeYxE](https://codepen.io/GhostRider/pen/ZEeYxE).

by juangallegosnoya